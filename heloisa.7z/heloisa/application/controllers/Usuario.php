<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


class Usuario extends MY_Controller{

    public function cadastro(){
        $this->show('Ok!');
    }

}