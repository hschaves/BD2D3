<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class SampleModel extends CI_Model{

    public function action_one()  {
        
    }


    public function action_two()
    {
        # code...
    }
}